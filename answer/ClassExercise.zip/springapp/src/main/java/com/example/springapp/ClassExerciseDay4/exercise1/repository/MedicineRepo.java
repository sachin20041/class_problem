package com.example.springapp.ClassExerciseDay4.exercise1.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springapp.ClassExerciseDay4.exercise1.model.Medicine;

public interface MedicineRepo extends JpaRepository<Medicine,Integer>{
    
}
